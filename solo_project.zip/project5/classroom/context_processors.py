from typing import get_origin
from .models import ClassRoom
#from .views.room.Single

'''
def Global(request):
    context ={
        'rooms':ClassRoom
    }
    return context 
'''
